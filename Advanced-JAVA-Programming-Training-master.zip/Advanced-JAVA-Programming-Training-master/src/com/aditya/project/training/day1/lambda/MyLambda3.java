package com.aditya.project.training.day1.lambda;

@FunctionalInterface
public interface MyLambda3 {

    Employee update(Employee e, String name);
}
