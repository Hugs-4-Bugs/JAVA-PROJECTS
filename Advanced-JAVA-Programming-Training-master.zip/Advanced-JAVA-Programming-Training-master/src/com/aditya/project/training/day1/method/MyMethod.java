package com.aditya.project.training.day1.method;

@FunctionalInterface
public interface MyMethod {

    int myMethod(int a, int b);
}
