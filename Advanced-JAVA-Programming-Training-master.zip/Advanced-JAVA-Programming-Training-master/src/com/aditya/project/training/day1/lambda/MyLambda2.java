package com.aditya.project.training.day1.lambda;

@FunctionalInterface
public interface MyLambda2 {

    int add(int x, int y);
}
