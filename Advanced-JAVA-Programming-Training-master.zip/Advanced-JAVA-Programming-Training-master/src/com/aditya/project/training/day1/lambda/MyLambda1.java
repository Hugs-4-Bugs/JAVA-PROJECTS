package com.aditya.project.training.day1.lambda;

@FunctionalInterface
public interface MyLambda1 {

    void add(int x, int y);
}
