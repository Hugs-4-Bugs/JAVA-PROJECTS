package com.sudarshan.testcicd.model;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class Person {
    private Long id;
    private String firstName;
    private String lastName;
}
