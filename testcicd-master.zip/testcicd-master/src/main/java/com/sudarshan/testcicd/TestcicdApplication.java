package com.sudarshan.testcicd;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TestcicdApplication {

	public static void main(String[] args) {
		SpringApplication.run(TestcicdApplication.class, args);
	}

}
