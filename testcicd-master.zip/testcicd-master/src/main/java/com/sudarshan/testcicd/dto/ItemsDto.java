package com.sudarshan.testcicd.dto;

public class ItemsDto {
    private MetaDto metaDto;
}

class MetaDto {
    private PersonSchemaDto person;
}

class PersonSchemaDto {

}