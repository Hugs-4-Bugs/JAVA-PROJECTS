package com.sudarshan.testcicd;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TestcicdApplicationTests {

	@Test
	void contextLoads() {
	}

}
