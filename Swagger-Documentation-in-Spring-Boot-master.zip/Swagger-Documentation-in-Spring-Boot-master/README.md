# Swagger-Documentation-in-Spring-Boot
In this project, I have worked on Documentation of Spring Boot REST APIs using Swagger Implementation.

# How to run this project :

Run the SwaggerImplementationApplication.java and visit http://localhost:8080/swagger-ui.html to see the APIs documentation.
