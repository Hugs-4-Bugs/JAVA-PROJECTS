package com.aditya.project.actuator;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HealthCheckApplicationTests {

	@Test
	void contextLoads() {
	}

}
