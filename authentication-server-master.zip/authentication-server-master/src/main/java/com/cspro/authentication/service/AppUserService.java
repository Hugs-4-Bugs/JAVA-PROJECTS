package com.cspro.authentication.service;

import org.springframework.security.core.userdetails.UserDetailsService;

public interface AppUserService extends UserDetailsService {

}
