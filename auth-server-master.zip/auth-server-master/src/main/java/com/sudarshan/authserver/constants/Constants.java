package com.sudarshan.authserver.constants;

public class Constants {

    public static final String AUTH_HEADER = "Authorization";
    public static final String BEARER = "Bearer ";
}
