package com.sudarshan.portal;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DataEntryPortalApplicationTests {

	@Test
	void contextLoads() {
	}

}
