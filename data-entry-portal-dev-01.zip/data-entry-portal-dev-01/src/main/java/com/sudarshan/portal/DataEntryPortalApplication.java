package com.sudarshan.portal;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DataEntryPortalApplication {

	public static void main(String[] args) {
		SpringApplication.run(DataEntryPortalApplication.class, args);
	}

}
