# HouseKeepingSystem_using_JSP_Servlets_JDBC
This is a project which involves the management of house keeping system that includes the workers and their tasks which  are stored in a database and they are given tasks according to user's choice.
