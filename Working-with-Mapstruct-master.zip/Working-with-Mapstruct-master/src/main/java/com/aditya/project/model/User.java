package com.aditya.project.model;

import lombok.Data;

@Data
public class User {

    private String name;
    private int age;
}
