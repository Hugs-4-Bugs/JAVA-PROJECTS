# Java-SpringBoot-Master-Web-Project
In this project, I have worked on a basic prototype of a project that can be extended for any other application, using Spring Boot and Thymeleaf. 
