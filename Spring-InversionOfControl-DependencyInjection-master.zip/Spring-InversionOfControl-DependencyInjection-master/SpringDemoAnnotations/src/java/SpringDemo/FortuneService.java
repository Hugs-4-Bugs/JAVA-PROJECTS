
package SpringDemo;

public interface FortuneService {
    
    public String getFortune();
}
