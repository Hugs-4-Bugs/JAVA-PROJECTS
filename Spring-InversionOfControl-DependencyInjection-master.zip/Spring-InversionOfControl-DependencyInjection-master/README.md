# Spring-InversionOfControl-DependencyInjection
In this, I have implemented the Concept of Inversion of Control and Dependency Injection in Spring JAVA using all 3 ways : XML Configuartion, Java Annotations and Java Code using Netbeans 8.0.2  
