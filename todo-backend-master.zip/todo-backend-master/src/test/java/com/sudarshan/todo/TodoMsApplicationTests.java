package com.sudarshan.todo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TodoMsApplicationTests {

	@Test
	void contextLoads() {
	}

}
