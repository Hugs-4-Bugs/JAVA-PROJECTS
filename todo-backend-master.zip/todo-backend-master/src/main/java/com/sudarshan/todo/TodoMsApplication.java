package com.sudarshan.todo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TodoMsApplication {

	public static void main(String[] args) {
		SpringApplication.run(TodoMsApplication.class, args);
	}

}
