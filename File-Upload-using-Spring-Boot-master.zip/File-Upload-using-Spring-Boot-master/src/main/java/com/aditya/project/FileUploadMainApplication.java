package com.aditya.project;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FileUploadMainApplication {

    public static void main(String[] args) {
        SpringApplication.run(FileUploadMainApplication.class, args);
    }
}