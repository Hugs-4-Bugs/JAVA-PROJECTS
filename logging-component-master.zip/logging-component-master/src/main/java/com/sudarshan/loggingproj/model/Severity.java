package com.sudarshan.loggingproj.model;

public enum Severity {
    INFO, ERROR, WARNING, DEBUG, TRACE
}
