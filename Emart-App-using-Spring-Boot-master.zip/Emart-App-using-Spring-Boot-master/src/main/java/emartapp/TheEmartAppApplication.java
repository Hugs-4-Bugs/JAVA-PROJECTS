package emartapp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TheEmartAppApplication
{
	public static void main(String[] args) {
		SpringApplication.run(TheEmartAppApplication.class, args);
	}
}
