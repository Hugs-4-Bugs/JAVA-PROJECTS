# Emart-App-using-Spring-Boot
In this project, I have worked on an Emart Website where the user can login as a Seller to add various products in the stocks as well as a Buyer to buy the products added by the seller of his choice.
