# MySQL-DB-WebApp-using-JAVA-Spring-Hibernate
In this project, I have created a Customer Database Management App using Spring 4.3.25 and Hibernate 5.4.11 and MySQL Workbench 8.0 in Apache Netbeans 11.3
