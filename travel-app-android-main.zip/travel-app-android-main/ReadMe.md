# Travel App - Android


App name: Trip Genie


App Function: Book Travel Packages


Test the App: [APK File](./Team7.apk) (Download & Install on Android Device)


For more details, see the [Report](./CS175Group7ProjectReport.pdf) or the [Presentation](TripGeniePresentation.pdf).

