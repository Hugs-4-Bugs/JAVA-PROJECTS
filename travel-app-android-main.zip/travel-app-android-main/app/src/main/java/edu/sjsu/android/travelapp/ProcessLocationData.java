package edu.sjsu.android.travelapp;

public class ProcessLocationData {

}
