package edu.sjsu.android.travelapp;

public interface RecyclerViewInterface {
    void onItemClick(int position);
}
