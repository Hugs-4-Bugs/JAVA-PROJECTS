INSERT INTO customers(id, name, company) VALUES(1, 'Adi', 'Self');
INSERT INTO customers(id, name, company) VALUES(2, 'Aditya', 'Self');

INSERT INTO orders(id, price, quantity, customer_id) VALUES(1, 25.5, 2, 1);
INSERT INTO orders(id, price, quantity, customer_id) VALUES(2, 35.5, 4, 1);
