package com.aditya.project.hateoas;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HateoasApplicationTests {

    @Test
    void contextLoads() {
    }

}
