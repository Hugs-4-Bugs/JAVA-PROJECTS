package com.sudarshan.day5.exceptions;

public class LowBalanceException extends Exception {
	
	public LowBalanceException(String message) {
		super(message);
	}
}