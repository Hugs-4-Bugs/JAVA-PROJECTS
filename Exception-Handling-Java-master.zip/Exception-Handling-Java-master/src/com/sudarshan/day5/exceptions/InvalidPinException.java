package com.sudarshan.day5.exceptions;

public class InvalidPinException extends Exception {
	
	public InvalidPinException(String message) {
		super(message);
	}
}
