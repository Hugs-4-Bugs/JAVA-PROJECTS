package com.sudarshan.day5.exceptions;

public class EmployeeNameInvalidException extends Exception {
	
	public EmployeeNameInvalidException(String message) {
		super(message);
	}
}
