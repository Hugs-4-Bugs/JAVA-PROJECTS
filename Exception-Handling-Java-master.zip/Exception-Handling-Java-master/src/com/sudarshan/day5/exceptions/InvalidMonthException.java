package com.sudarshan.day5.exceptions;

public class InvalidMonthException extends Exception {

	public InvalidMonthException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

}
