package com.sudarshan.day5.exceptions;

public class TaxNotEligibleException extends Exception {
	public TaxNotEligibleException(String message) {
		super(message);
	}
}
