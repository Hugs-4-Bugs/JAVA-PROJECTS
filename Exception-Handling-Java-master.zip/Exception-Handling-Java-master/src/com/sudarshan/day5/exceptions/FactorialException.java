package com.sudarshan.day5.exceptions;

public class FactorialException extends Exception {

	public FactorialException(String message) {
		super(message);
	}

}
