package com.sudarshan.day5.exceptions;

public class InvalidInputException extends Exception {
	public InvalidInputException(String message) {
		super(message);
	}
}
