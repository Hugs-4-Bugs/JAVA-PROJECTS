package com.sudarshan.day5.exceptions;

public class CountryNotValidException extends Exception {
	public CountryNotValidException(String message) {
		super(message);
	}
}
