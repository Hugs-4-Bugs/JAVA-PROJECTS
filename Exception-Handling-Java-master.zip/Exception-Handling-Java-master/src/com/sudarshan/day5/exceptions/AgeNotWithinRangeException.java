package com.sudarshan.day5.exceptions;

public class AgeNotWithinRangeException extends Exception {
	 public AgeNotWithinRangeException(String message) {
		 super(message);
	 }
}
