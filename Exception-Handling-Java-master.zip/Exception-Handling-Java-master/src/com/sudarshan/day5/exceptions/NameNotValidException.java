package com.sudarshan.day5.exceptions;

public class NameNotValidException extends Exception {
	public NameNotValidException(String message) {
		super(message);
	}
}
