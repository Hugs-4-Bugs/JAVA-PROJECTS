package com.aditya.emailactivation.application;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EmailActivationApplication {
	
	public static void main(String[] args) {
		SpringApplication.run(EmailActivationApplication.class, args);
	}

}
