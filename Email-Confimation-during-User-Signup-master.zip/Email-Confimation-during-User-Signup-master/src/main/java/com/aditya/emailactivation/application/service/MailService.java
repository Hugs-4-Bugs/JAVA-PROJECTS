package com.aditya.emailactivation.application.service;

import com.aditya.emailactivation.application.model.Mail;

public interface MailService 
{
	public void sendEmail(Mail mail);
}
