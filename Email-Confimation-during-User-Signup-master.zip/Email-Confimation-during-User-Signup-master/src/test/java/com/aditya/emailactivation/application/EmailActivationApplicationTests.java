package com.aditya.emailactivation.application;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EmailActivationApplicationTests {

	@Test
	void contextLoads() {
	}

}
