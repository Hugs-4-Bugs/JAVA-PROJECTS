package com.aditya.project.async.exception;

public enum ErrorLevel {
    TECHNICAL,
    FUNCTIONAL
}
