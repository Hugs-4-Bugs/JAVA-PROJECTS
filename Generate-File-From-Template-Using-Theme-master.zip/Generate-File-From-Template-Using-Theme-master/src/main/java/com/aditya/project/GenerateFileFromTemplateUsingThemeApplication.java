package com.aditya.project;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GenerateFileFromTemplateUsingThemeApplication {

	public static void main(String[] args) {
		SpringApplication.run(GenerateFileFromTemplateUsingThemeApplication.class, args);
	}

}
