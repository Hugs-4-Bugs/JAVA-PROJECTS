# Multi-Module-Application-using-Spring-Boot
In this project, I have worked on a Spring Application which works on the principle of multi-module programming, creating REST APIs to perform all the CRUD operations on H2 Database.

# How to run this application :

Go to com.aditya.multimodule.application module and run the App.java Application.
