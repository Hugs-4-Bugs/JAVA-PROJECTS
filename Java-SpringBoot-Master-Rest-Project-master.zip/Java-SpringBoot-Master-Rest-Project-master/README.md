# Java-SpringBoot-Master-Rest-Project
In this project, I have created a basic Rest API using Spring Boot that can perform all CRUD operations including Authentication using Spring Security.
